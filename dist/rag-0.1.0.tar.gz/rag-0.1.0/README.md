# rag
Um pacote Python que dá acesso a um assistente que implementa técnicas de Retrieval-Augmented Generation (RAG).
